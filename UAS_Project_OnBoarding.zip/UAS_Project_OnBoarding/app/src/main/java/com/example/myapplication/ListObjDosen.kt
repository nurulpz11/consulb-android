package com.example.myapplication

data class ListObjDosen (
    var nama: String,
    var kompetensi: String,
    var gambar: String
)