package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class AppointmentActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_appointment2)
    }

    fun appointmentToMenuUtama(view: View?){
        val i = Intent(applicationContext, HalamanUtamaActivity::class.java)
        i.putExtra("Value1", "Sedang berada di halaman list dosen")
        startActivity(i)
    }
}