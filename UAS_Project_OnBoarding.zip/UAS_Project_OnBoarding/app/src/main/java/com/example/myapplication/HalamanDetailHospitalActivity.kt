package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class HalamanDetailHospitalActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_halaman_detail_hospital)
    }

    fun detailHospitalToHospital(view: View?){
        val i = Intent(applicationContext, HalamanHospitalActivity::class.java)
        i.putExtra("Value1", "Sedang berada di halaman list dosen")
        startActivity(i)
    }

    fun detailHospitalToDetailDokter(view: View?){
        val i = Intent(applicationContext, DetailDokterActivity::class.java)
        i.putExtra("Value1", "Sedang berada di halaman list dosen")
        startActivity(i)
    }
}