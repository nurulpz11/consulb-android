package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import com.example.myapplication.databinding.ActivityMain2Binding


class MainActivity2 : AppCompatActivity() {

    val mataPelajaran = arrayOf(
        "Matematika",
        "Pemograman Mobile",
        "Agama",
        "Bahasa Inggris",
        "Jaringan Dasar",
        "Pengembangan Game",
        "Animasi",
        "Pemograman Web",
        "Konsep Teknologi Informasi",
        "Sistem Operasi",
        "Aljabar Matriks",
    )
    private lateinit var binding: ActivityMain2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_2)
        binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)
        val arrayAdapter = ArrayAdapter<String>(this,
            android.R.layout.simple_list_item_1, mataPelajaran)
        binding.listView.adapter = arrayAdapter

        binding.listView.setOnItemClickListener  {
                parent: AdapterView<*>?, view: View?, posisi: Int, id: Long ->

            Toast.makeText(
                this, "Klik id: " + (posisi+1) + " " +
                        mataPelajaran[posisi], Toast.LENGTH_SHORT
            ).show()
        }

    }
}


