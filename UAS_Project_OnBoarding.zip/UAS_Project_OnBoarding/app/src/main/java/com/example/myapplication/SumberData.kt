package com.example.myapplication

class SumberData {
    companion object {
        fun buatSetData(): ArrayList<ListObjDosen> {
            val list = ArrayList<ListObjDosen>()
            //list bisa didapatkan/copas di web pcr.
            list.add(
                ListObjDosen(
                    "Muhammad Mahrus Zain, S.S.T., M.T.I.",
                    "IoT, Application Development, Data Science",
                    "https://www.rspermatajonggol.com/wp-content/uploads/2022/06/mona-oke-300x300.png"
                )
            )
            list.add(
                ListObjDosen(
                    "Satria Perdana Arifin, S.T.,M.T.I",
                    "IT Governance, Computer Networking and Security,Enterprise Architecture, Bussines Intelligence",
                    "https://pcr.ac.id/assets/images/pegawai/SPA20211215072819.JPG"
                )
            )
            list.add(
                ListObjDosen(
                    "Anggy Trisnadoli, S.ST.,M.T.",
                    "Multimedia (Game & Animation), Web Programming",
                    "https://pcr.ac.id/assets/images/pegawai/ATD20211215072942.JPG"
                )
            )
            list.add(
                ListObjDosen(
                    "Istianah Muslim, S.T.,M.T.",
                    "Logistik, Supply Chain Management, IMK, Management Proyek",
                    "https://pcr.ac.id/assets/images/pegawai/ISM20211215073106.jpg"
                )
            )
            list.add(
                ListObjDosen(
                    "Indah Lestari, S.ST.,M.T.",
                    "Data Structures & Algorithms (Java), Software Engineering, Image Processing",
                    "https://pcr.ac.id/assets/images/pegawai/IDI20211215072827.JPG"
                )
            )
            list.add(
                ListObjDosen(
                    "Dr. Dadang Syarif Sihabudin Sahid, S.Si,M.Sc.",
                    "Web Programming, System Development and Aplication, IT Project Management",
                    "https://pcr.ac.id/assets/images/pegawai/DDS20211215072937.jpg"
                )
            )
            return list
        }
    }
}